package team.t9001.saad.controller;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

/**
 * desc:发表文章控制类
 * Created by huangzhe on 2016/11/17.
 */
@ContextConfiguration(locations = "file:src/main/resources/application.xml")
public class ArticleControllerTest extends AbstractTransactionalJUnit4SpringContextTests {
    public void testList(){
//        HttpUtil.post();
    }
}
