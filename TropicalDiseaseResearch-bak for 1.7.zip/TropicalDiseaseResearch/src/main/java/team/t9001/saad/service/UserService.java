package team.t9001.saad.service;

import org.springframework.stereotype.Service;
import team.t9001.saad.model.Article;

import java.util.List;

/**
 * desc:
 * Created by huangzhe on 2016/11/15.
 */
@Service
public class UserService {

}
