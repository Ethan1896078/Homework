package team.t9001.saad.common;

/**
 * desc:
 * Created by huangzhe on 2016/11/17.
 */
public interface UrlConstants {
    /** 添加文章 */
    String add_article = "add_article";
    /** 获取文章列表 */
    String get_article_list = "get_article_list";
}
