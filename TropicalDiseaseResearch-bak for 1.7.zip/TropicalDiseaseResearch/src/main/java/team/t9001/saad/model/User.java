package team.t9001.saad.model;

/**
 * desc:
 * Created by huangzhe on 2016/11/16.
 */
public class User {
}
